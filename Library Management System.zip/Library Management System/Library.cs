using System;
using System.Collections.Generic;
using System.Linq;

public class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public string ISBN { get; set; }
    public bool IsCheckedOut { get; set; }
}

public class User
{
    public string Name { get; set; }
    public List<Book> BorrowedBooks { get; set; } = new List<Book>();
    public const int MaxBooks = 5; // Limit to 5 books at a time
}

public class Library
{
    private List<Book> books = new List<Book>();
    private List<User> users = new List<User>();

    // Method to add books to the library
    public void AddBook(Book book)
    {
        books.Add(book);
        Console.WriteLine($"Added {book.Title} by {book.Author}");
    }

    // Method to add users to the library
    public void AddUser(User user)
    {
        users.Add(user);
        Console.WriteLine($"Added user {user.Name}");
    }

    // Method to search books by title
    public Book SearchBookByTitle(string title)
    {
        return books.FirstOrDefault(b => b.Title.IndexOf(title, StringComparison.OrdinalIgnoreCase) >= 0);
    }

    // Method to borrow a book
    public bool BorrowBook(User user, Book book)
    {
        if (user.BorrowedBooks.Count >= User.MaxBooks)
        {
            Console.WriteLine($"{user.Name} cannot borrow more books. Limit of {User.MaxBooks} reached.");
            return false;
        }

        if (book.IsCheckedOut)
        {
            Console.WriteLine($"{book.Title} is already checked out.");
            return false;
        }

        book.IsCheckedOut = true;
        user.BorrowedBooks.Add(book);
        Console.WriteLine($"{user.Name} borrowed {book.Title}");
        return true;
    }

    // Method to check in a book
    public bool CheckInBook(User user, Book book)
    {
        if (!user.BorrowedBooks.Contains(book) || !book.IsCheckedOut)
        {
            Console.WriteLine($"{user.Name} has not borrowed {book.Title} or the book is not checked out.");
            return false;
        }

        book.IsCheckedOut = false;
        user.BorrowedBooks.Remove(book);
        Console.WriteLine($"{user.Name} checked in {book.Title}");
        return true;
    }
}
