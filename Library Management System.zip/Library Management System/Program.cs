using System;

public class Program
{
    public static void Main()
    {
        Library library = new Library();

        // Adding some books to the library
        Book gatsby = new Book { Title = "The Great Gatsby", Author = "F. Scott Fitzgerald", ISBN = "123456789" };
        Book mockingbird = new Book { Title = "To Kill a Mockingbird", Author = "Harper Lee", ISBN = "987654321" };
        library.AddBook(gatsby);
        library.AddBook(mockingbird);

        // Adding some users to the library
        User user1 = new User { Name = "John Doe" };
        library.AddUser(user1);

        // Borrowing books
        library.BorrowBook(user1, gatsby);
        library.BorrowBook(user1, mockingbird);

        // Checking in a book
        library.CheckInBook(user1, gatsby);

        // Attempting to check in a book that was not borrowed or not checked out
        library.CheckInBook(user1, new Book { Title = "Moby Dick", Author = "Herman Melville", ISBN = "192837465" });

        // Prompt the user to input a book title to search for
        Console.WriteLine("Enter the title of the book to search:");
        string titleToSearch = Console.ReadLine();

        // Search for the book
        Book foundBook = library.SearchBookByTitle(titleToSearch);
        if (foundBook != null)
        {
            Console.WriteLine($"The book '{foundBook.Title}' is available in the library.");
        }
        else
        {
            Console.WriteLine($"The book '{titleToSearch}' is not in the collection.");
        }
    }
}
